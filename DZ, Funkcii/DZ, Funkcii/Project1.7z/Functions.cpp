#include <iostream>
using namespace std;


int search_number(int arr[], int size, int x)
{
	for (int i = 0; i < size; i++)
	{
		cout << arr[i] << " ";
		if (arr[i] == x)
		{
			cout << endl;
			return 1;
		}
			
	}
	cout << endl;
	return 0;
}

int mass_sum(int arr[], int size)
{
	int sum = 0;
	for (int i = 0; i < size; i++)
	{
		sum += arr[i];
	}
	return sum;
}