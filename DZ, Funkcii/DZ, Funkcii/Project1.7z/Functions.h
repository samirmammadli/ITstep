#pragma once
#include <iostream>
#include <time.h>
using namespace std;

int search_number(int arr[], int size, int x);
int mass_sum(int arr[], int size);
