#include "Functions.h"


void main()
{
	srand(time(NULL));
	int oper = 0;
	cout << "Vvedite nomer zadaniya: ";
	cin >> oper;
	if (oper == 1)
	{
		const int size = 10;
		int value, arr[size];
		bool check_value_exist;
		cout << "Vvedite chislo: ";
		cin >> value;
		for (int i = 0; i < size; i++)
		{
			arr[i] = rand() % 100 + 1;
		}
		check_value_exist = search_number(arr, size, value);
		if (check_value_exist)
			cout << "True!\n";
		else
			cout << "False!\n";
	}
	else if (oper == 2)
	{
		const int size = 10;
		int arr[size];
		for (int i = 0; i < size; i++)
		{
			arr[i] = rand() % 150;
			cout << arr[i] << " ";
		}
		cout << endl;
		cout << "Summa elementov : " << mass_sum(arr, size) << endl;
	}
	


}